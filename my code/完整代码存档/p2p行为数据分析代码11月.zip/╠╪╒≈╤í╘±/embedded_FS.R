df<-p2p.model
iv<-get_var_info(df,names(df),"def",get_IV)
temp<-names(iv[iv>0.02])
###################################################C50��Ƕ��Ҫ��
set.seed(123)
library(C50)
while(3>2){
  boost<-C5.0(def~.,data=df[,c(temp,"def")],trials=100,control=controls.C50)
  varimp<-C5imp(boost)
  temp<-row.names(varimp)[varimp>99]
  if(length(temp)<70){break}
}
useful<-temp
###################################################���ɭ����Ƕ��Ҫ��
df<-p2p.model
set.seed(123)
library(Boruta)
boruta<-Boruta(def~.,data=df,doTrace = 2, ntree = 200)
useful<-getSelectedAttributes(boruta)

