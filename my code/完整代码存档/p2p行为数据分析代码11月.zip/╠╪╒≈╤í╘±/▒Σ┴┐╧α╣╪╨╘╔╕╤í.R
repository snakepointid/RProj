info_matr<-function(vars,df,targ,way){
  l<-length(vars)
  info.matr<-matrix(NA,nrow=l,ncol=l,dimnames = list(vars,vars))
  c.p.matr<-matrix(NA,nrow=l,ncol=l,dimnames = list(vars,vars))
  for(i in 1:(l-1)){
    print(i)
    temp.i<-way(df[,vars[i]],df[,targ])
    for(j in (i+1):l){
      print(j)
      vec<-paste(df[,vars[i]],df[,vars[j]])
      temp.j<-way(vec,df[,targ])
      temp<-temp.j-temp.i
      c.p<-nor_test(df[,vars[i]],df[,vars[j]])
      c.p.matr[vars[i],vars[j]]<-c.p
      info.matr[vars[i],vars[j]]<-temp
      }
  }
  return(list(info.matr,c.p.matr))
}


keep.or.drop<-function(info.matr,a){
  while(2>1){
    l<-length(info.matr[,1])
    if(length(info.matr[2,])<a)break
    drop.p<-apply(info.matr[,2:l],2,function(s)min(s,na.rm=T))%>%which.min()+1
    info.matr<-info.matr[,-drop.p]
    info.matr<-info.matr[-drop.p,]
    paste("��ʣ",l)%>%print()
  }
  keep.vars<-colnames(info.matr)
  return(keep.vars)
}

############################################################������������Լ���
num_test<-function(vec,tar){
  ft<-summary(aov(vec~tar))[[1]][1,5]
  return(ft)
}
############################################################��ɢ��������Լ���
nor_test<-function(vec,tar){
  pv<-chisq.test(vec,tar)$p.value
  return(pv)
}
############################################################�����Լ���
cor_test<-function(df,varlist,cor.rate,iv.list){
  useless<-c()
  for(i in varlist){
    for(j in varlist){
      if(class(df[,i])=="numeric"&class(df[,j])=="numeric"){
        a<-cor.test(df[,i],df[,j])$estimate
        if(a>cor.rate){
          if(iv.list[i]<iv.list[j]){
            print(a)
            print(iv.list[j])
            useless<-c(useless,j)
          }
        }
      }
    }
  }
  return(unique(useless))
}

