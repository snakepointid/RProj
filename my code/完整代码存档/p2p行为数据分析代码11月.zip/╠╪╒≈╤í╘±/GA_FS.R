library(GA)
############################################
df<-p2p.model
targ<-"def"
############################################
get_sugg<-function(df,targ,n){
l<-length(df[,1])
sugg<-c()
for(i in 1:n){
boos<-sample(1:l,l,replace=T)
rpart<-rpart(def~.,data=df[boos,],control=controls.rpart)
use<-names(rpart$variable.importance)
temp<-vars%in%use%>%as.numeric()
sugg<-rbind(sugg,temp)
}
return(sugg)
}

fitness <- function(string,con=controls.rpart) {
  inc <- which(string == 1)
  useful<-vars[inc]
  fit<-glm(def~.,data=df[,c(useful,"def")],family = "binomial")
  -AIC(fit)
}
vars<-useful
vars<-vars[vars!=targ]
sugg<-get_sugg(df,targ,10)
  
GA<-ga(type="binary",fitness = fitness,parallel = T,
       nBits = length(vars),names=vars,maxiter=100,
       seed=123,monitor = plot)

useful<-vars[GA@solution[25,]==1]

