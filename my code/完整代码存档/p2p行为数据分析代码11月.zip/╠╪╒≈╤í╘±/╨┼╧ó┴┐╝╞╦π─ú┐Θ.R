library(dplyr)
get_IV<-function(prob,target){
  prob<-leave_0_point(prob,target)
  mp<-is.na(prob)%>%which()
  prob[mp]<-"missing"
  
  temp<-table(target,prob)
  bad.vec<-temp[2,]
  good.vec<-temp[1,]
  
  bads<-sum(bad.vec)
  goods<-sum(good.vec)
  
  bad.woe<-bad.vec/bads
  good.woe<-good.vec/goods
  woe<-log(bad.woe/good.woe)
  dif<-bad.woe-good.woe
  ivi<-dif*woe
  iv<-sum(ivi)
  return(iv)
}

get_MI<-function(predict,target){
  predict<-leave_0_point(predict,target)
  np<-which(is.na(predict))
  vec[np]<-"missing"
  
  joint<-table(target,predict)%>%prop.table()
  temp<-table(predict)%>%prop.table()
  margin1<-matrix(temp,nrow=1)
  temp<-table(target)%>%prop.table()
  margin2<-matrix(temp,ncol=1)
  margin<-margin2%*%margin1
  temp<-joint/margin
  temp<-log(temp)
  temp<-temp*joint
  MI<-sum(temp)
  return(MI)
}
get_IG<-function(vec,target,miss=TRUE){
  vec<-leave_0_point(vec,target)
  np<-which(is.na(vec))
  vec[np]<-"missing"
  
  tb<-prop.table(table(target))
  ptb<--tb*log2(tb)
  I0<-sum(ptb)
  tb<-prop.table(table(target,vec),2)
  ptb<--tb*log2(tb)
  ptb<-apply(ptb,2,function(s)sum(s,na.rm = T))
  tb<-prop.table(table(vec))
  I1<-sum(ptb*tb)
  IG<-I0-I1
  ptb<--tb*log2(tb)
  IIG<-sum(ptb)
  IGR<-IG/IIG
  return(IGR)
}

get_var_info<-function(df,vars,targ,way){
  InFo<-c()
  for(i in vars){
    if(i!=targ){
      info<-way(df[,i],df[,targ])
      names(info)<-i
      InFo<-c(InFo,info)
      paste(i,"�Ѿ��õ���Ϣ��")%>%print()
    }
  }
  return(InFo[order(InFo,decreasing = T)])
}

leave_0_point<-function(prob,target){
  prob<-prob%>%as.character()
  
  temp<-table(target,prob)
  te<-names(temp[1,])
  mp<-which(temp[1,]==0|temp[2,]==0)
  last<-length(temp[1,])
  all<-1:last
  nmp<-all[!all%in%mp]
  big<-max(nmp)
  for(i in mp){
    if(i>big){
      cp<-te[i]
      c2p<-te[big]
      prob[prob==cp]<-c2p
    }else{
      cp<-te[i]
      c2p<-te[i+1]
      prob[prob==cp]<-c2p
    }
  }
  return(prob)
}


