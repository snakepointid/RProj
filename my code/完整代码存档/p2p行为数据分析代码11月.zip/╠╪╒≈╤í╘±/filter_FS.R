df<-p2p.model
#############################################��ivֵ����ɸѡ
set.seed(123)
temp<-sepe_var(df,"def")
dis.var<-temp[[1]]
con.var<-temp[[2]]
iv.dis<-get_var_info(df,dis.var,"def",get_IV)
iv.con<-get_var_info(df,con.var,"def",get_IV)
use.dis<-names(iv.dis[iv.dis>0.02])
use.con<-names(iv.con[iv.con>0.02])
corr<-c()
for(i in use.con){
  corr[i]<-num_test(df[,i],df[,"def"])
}
corr.con<-corr[order(corr)]
use.con<-names(corr.con)[corr.con<0.05]
useless<-cor_test(df,use.con,0.6,corr.con)
useful<-c(use.dis,use.con)
useful<-useful[!useful%in%useless]
###############################################
df<-p2p.model
rpart<-rpart(def~.,data=df,control=controls.rpart)
useful<-names(rpart$variable.importance)

