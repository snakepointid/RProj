
balance_cut<-function(df,prop){
  ln<-length(df[,1])
  num<-round(prop*ln)
  level<-levels(df[,"def"])
  samples1<-sample(which(df[,"def"]==level[1]),num,replace = F)
  samples2<-sample(which(df[,"def"]==level[2]),num,replace = F)
  samples<-c(samples1,samples2)
  for(i in 1:5){
    samples<-sample(samples,length(samples),replace = F)
  }
  traindf<-df[-samples,]
  testdf<-df[samples,]
  return(list("train"=traindf,"test"=testdf))
}

random_cut<-function(df,prop){
  ln<-length(df[,1])
  num<-round(prop*ln)
  samples<-sample(1:ln,num,replace = F)
  traindf<-df[-samples,]
  testdf<-df[samples,]
  return(list("train"=traindf,"test"=testdf))
}

