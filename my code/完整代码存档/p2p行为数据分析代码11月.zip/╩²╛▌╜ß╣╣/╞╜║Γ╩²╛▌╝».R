balance_df_cut<-function(df,target){
  level<-levels(df[,target])
  len1<-length(which(df[,target]==level[1]))
  len2<-length(which(df[,target]==level[2]))
  balance_num<-ifelse(len1>len2,len2,len1)
  samples1<-sample(which(df[,target]==level[1]),balance_num,replace = F)
  samples2<-sample(which(df[,target]==level[2]),balance_num,replace = F)
  samples<-c(samples1,samples2)
  for(i in 1:5){
    samples<-sample(samples,length(samples),replace = F)
  }
  df<-df[samples,]
  return(df)
}

balance_df_add<-function(df,target){
  level<-levels(df[,target])
  len1<-length(which(df[,target]==level[1]))
  len2<-length(which(df[,target]==level[2]))
  if(len1>len2){
  samples1<-sample(which(df[,target]==level[1]),len1,replace = F)
  samples2<-sample(which(df[,target]==level[2]),len2,replace = F)
  samples3<-sample(which(df[,target]==level[2]),len1-len2,replace = T)}else{
    samples1<-sample(which(df[,target]==level[1]),len1,replace = F)
    samples2<-sample(which(df[,target]==level[2]),len2,replace = F)
    samples3<-sample(which(df[,target]==level[1]),len2-len1,replace = T)
  }
  samples<-c(samples1,samples2,samples3)
  for(i in 1:5){
    samples<-sample(samples,length(samples),replace = F)
  }
  df<-df[samples,]
  return(df)
}

balance_df_rand<-function(df,targ){
  temp<-table(df[,targ])
  t1<-temp[1]
  t2<-temp[2]
  tn<-names(temp)
  w0<-1/t1*2
  w1<-1/t2*2
  prob<-as.character(df[,targ])
  temp<-prob
  prob[temp==tn[1]]<-w0
  prob[temp==tn[2]]<-w1
  ln<-length(df[,1])
  samp<-sample(1:ln,ln,replace = T,prob = prob)
  ndf<-df[samp,]
  return(ndf)
}

