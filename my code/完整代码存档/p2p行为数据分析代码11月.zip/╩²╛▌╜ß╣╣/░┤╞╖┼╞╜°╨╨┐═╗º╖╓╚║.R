library(dplyr)
##################�Ȼ�ȡÿ��Ʒ�Ƶ�Ƶ��
sep_popu<-function(wdf,ncluster,target,niter){
  iv<-c()
  cen.l<-list()
  for(i in 1:niter){
  km<-kmeans(wdf,ncluster)
  clus<-km$cluster
  cen.l[[i]]<-km$center
  cv<-get_iv(clus,target)
  iv<-c(iv,cv)
  }
  max(iv)%>%print()
  p<-which.max(iv)
  return(cen.l[[p]])
}

get_wide_df<-function(df,nvar){
  #�Ȼ�ȡ����������Ƶ������
  v<-c()
  for(i in names(df)){
  v1<-df[,1]%>%as.character()
  v<-c(v,v1)
  }
  vl<-table(v)
  vl<-vl[-which(names(vl)=="")]
  vl<-vl[order(vl,decreasing = T)]
  var.l<-names(vl)[1:nvar]
  #��ʼ��������ݼ�
  matr<-matrix()
  n=1
  for(i in var.l){
    print(i)
    p<-0
    value<-rep(0,length(df[,1]))
    for(j in names(df)){
      pl<-which(df[,j]==i)
      p<-c(p,pl)
    }
    value[p]<-1
    if(n==1){
      matr<-value
    }else{
      matr<-cbind(matr,value)
    }
    n<-n+1
  }
  wdf<-data.frame(matr)
  names(wdf)<-var.l
  return(wdf)
}

