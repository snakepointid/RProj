cross_validation<-function(df,folds){
  all.ns<-length(df[,1])
  se.ns<-all.ns/folds
  cv.list<-list()
  remain<-1:all.ns
  for(i in 1:folds){
    samp<-sample(remain,se.ns,replace = F)
    cv.list[[i]]<-samp
    remain<-remain[!remain%in%samp]
  }
  return(cv.list)
}

cv_balance<-function(df,folds,targ){
  g_b<-as.character(df[,targ])
  cv.list<-list()
  remain.g<-which(g_b=="0")
  remain.b<-which(g_b=="1")
  
  g.ns<-length(remain.g)
  g.ns<-g.ns/folds
  b.ns<-length(remain.b)
  b.ns<-b.ns/folds
  for(i in 1:folds){
    samp.g<-sample(remain.g,g.ns,replace = F)
    samp.b<-sample(remain.b,b.ns,replace = F)
    all<-c(samp.b,samp.g)
    cv.list[[i]]<-sample(all,length(all),replace = F)
    remain.g<-remain.g[!remain.g%in%samp.g]
    remain.b<-remain.b[!remain.b%in%samp.b]
  }
  return(cv.list)
}

