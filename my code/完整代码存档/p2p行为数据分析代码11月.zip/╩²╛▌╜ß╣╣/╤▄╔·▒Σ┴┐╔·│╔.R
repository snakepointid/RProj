outlier_count<-function(df,quant=F){
  count.con<-c()
  count.dis<-c()
  for(i in names(df)){
    if(is.numeric(df[,i])){
      temp<-get_outlier(df[,i],quant=quant,change=FALSE)
      count.con<-c(count.con,temp)}else{
        print(i)
        temp<-get_outlier_dis(df[,i])
        count.dis<-c(count.dis,temp)}
  }
  temp.con<-c(count.con,1:length(df[,1]))
  temp.dis<-c(count.dis,1:length(df[,1]))
  return(list(table(temp.con)-1,table(temp.dis)-1))
}


misser_count<-function(df){
  temp<-apply(df,1,function(s)is.na(s)%>%which()%>%length())
  return(temp)
}

miss_valued<-function(df,targ){
  for(i in 1:length(df)){
    target<-df[,targ]%>%as.character()%>%as.numeric()
    temp<-table(target,df[,i])
    if(sum(temp[2,])<sum(target)*0.05){
      df[,i]<-df[,i]%>%as.character()
      mp<-which(is.na(df[,i]))
      df[mp,i]<-"missing"
      df[-mp,i]<-"valued"
      print(names(df)[i])
      names(df)[i]<-paste("mir_",names(df)[i],sep="")
    }
  }
  return(df)
}

get_mirror_df<-function(df,quant=F){
  df.mirror<-df
  for(i in 1:length(df)){
    df.mirror[,i]<-as.character(df.mirror[,i])
    df.mirror[,i]<-"normal"
    if(is.numeric(df[,i])){
      temp<-get_outlier(df[,i],quant=quant,change=FALSE)
      }else{
        temp<-get_outlier_dis(df[,i])
      }
    df.mirror[temp,i]<-"outer"
    temp<-which(is.na(df[,i]))
    df.mirror[temp,i]<-"missing"
    names(df.mirror)[i]<-paste("mir_",names(df)[i],sep="")
    }
  return(df.mirror)
}


get_comb_var<-function(df,vars,targ,a){
  new.iv<-c()
  ndf<-data.frame(df[,targ])
  names(ndf)<-"def"
  for(i in 1:(length(vars)-1)){
    print(i)
    for(j in (i+1):length(vars)){
      ivar<-vars[i]
      jvar<-vars[j]
      inv<-unique(df[,ivar])%>%length()
      jnv<-unique(df[,jvar])%>%length()
      if(inv<4&jnv<4){
      vec<-paste(df[,jvar],df[,ivar])
      temp<-get_IV(vec,df[,targ])
      if(temp>a){
        name<-paste(ivar,"&",jvar)
        ndf[,name]<-vec%>%as.factor()
      print(paste(ivar,"��",jvar,"��ɵ��±���ivΪ��",temp))
      }
      }
  }}
  return(ndf)
}


