df<-p2p.model
use<-c(useful,"def")
##############################################�ı����ݽṹ
set.seed(12)
temp<-balance_cut(df[,use],0.25)
train.p2p<-temp[["train"]]
test.p2p<-temp[["test"]]
train.mat <- sparse.model.matrix(def~., data = train.p2p)
train.l<-train.p2p[,"def"]%>%as.character()%>%as.numeric()
test.mat <- sparse.model.matrix(def~., data = test.p2p)
test.l<-test.p2p[,"def"]%>%as.character()%>%as.numeric()

##############################################�Ż�
dtrain <- xgb.DMatrix(data =train.mat,label = train.l)
dtest <- xgb.DMatrix(data =test.mat,label = test.l)
watchlist <- list(eval = dtest, train = dtrain)
param <- list(max.depth =3, eta = 0.07, silent = 0,gama=100,
              objective="binary:logistic",subsample=0.7,colsample_bytree=0.5,
              eval_metric=evalerror)
bst <- xgb.train(param, dtrain, nround =1000,watchlist=watchlist,maximize=TRUE)
pred <- predict(bst,test.mat)
ks(pred,test.l,plots = T)