df<-p2p.model
use<-c(useful,"def")
library(xgboost)
##############################################�ı����ݽṹ
train.mat <- sparse.model.matrix(def~., data = df[,use])
train.l<-df[,"def"]%>%as.character()%>%as.numeric()
##############################################�Ż�
evalerror <- function(preds, dtrain) {
  labels <- getinfo(dtrain, "label")
  err <- ks(preds,labels)
  return(list(metric = "ks", value = err))
}
dtrain <- xgb.DMatrix(data =train.mat,label = train.l)
param <- list(max.depth =3, eta = 0.07,objective="binary:logistic")
set.seed(123)
bst <- xgb.cv(params=param, data=dtrain,nround =200,showsd=TRUE,nfold=4,feval=evalerror)
wp<-bst$test.ks.mean%>%which.max()
bst$test.ks.mean[wp]
bst$test.ks.std[wp]
bst$train.ks.mean[wp]
bst$train.ks.std[wp]
