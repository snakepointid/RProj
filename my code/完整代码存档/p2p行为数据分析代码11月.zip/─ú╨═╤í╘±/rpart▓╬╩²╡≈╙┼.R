library(rpart)
########################################����ȡֵ
minsplit =30
cp =0.001
maxcompete =1
maxsurrogate =1
usesurrogate=1
xval =4
surrogatestyle =1
maxdepth = 8

########################################����ѡ��
df<-p2p.model
var.list<-use
########################################��ʼ����
oldks<-0
for(a in minsplit){
  for(b in cp){
    for(c in maxcompete){
      for(d in maxsurrogate){
        for(e in usesurrogate){
          for(f in xval){
            for(g in surrogatestyle){
              for(h in maxdepth){
                
                kss<-para_rpart(df,var.list,cv.list,ks,controls=rpart.control(minsplit = a,
                                                                             
                                                                             cp = b, 
                                                                             maxcompete = c,
                                                                             maxsurrogate = d, 
                                                                             usesurrogate = e, 
                                                                             xval = f,
                                                                             surrogatestyle = g, 
                                                                             maxdepth = h))
                print(kss[[1]])
                para<-c(a,b,c,d,e,f,g,h)
                names(para)<-c("minsplit","cp","maxcompete","maxsurrogate",
                               "usesurrogate","xval","surrogatestyle","maxdepth")
                
                newks<-kss[[1]]
                if(newks>oldks){
                  oldks<-newks
                  bestpara<-para
                  print(bestpara)
                }
                
              }
            }
          }
        }
      }
    }
  }
}


#####################################Ŀǰ���в���
controls.rpart<-rpart.control(minsplit =5,
                              cp =0.001,
                              maxcompete =1,
                              maxsurrogate =1,
                              usesurrogate=1,
                              xval =4,
                              surrogatestyle =1,
                              maxdepth = 8)
