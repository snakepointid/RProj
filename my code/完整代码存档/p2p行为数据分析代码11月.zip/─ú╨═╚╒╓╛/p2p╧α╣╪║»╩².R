
balance_cut<-function(df,prop){
  ln<-length(df[,1])
  num<-round(prop*ln)
  level<-levels(df[,"def"])
  samples1<-sample(which(df[,"def"]==level[1]),num,replace = F)
  samples2<-sample(which(df[,"def"]==level[2]),num,replace = F)
  samples<-c(samples1,samples2)
  for(i in 1:5){
    samples<-sample(samples,length(samples),replace = F)
  }
  traindf<-df[-samples,]
  testdf<-df[samples,]
  return(list("train"=traindf,"test"=testdf))
}
variable_select_ga<-function(df,vars){
  old.1<-0.2
  var.t<-c()
  vars.p<-table(vars)%>%prop.table()
  var.list<-table(vars)%>%names()
  l<-length(var.list)
  while(l>30){
    tryCatch({
      fboos<-sample(var.list,l,replace=T,prob=vars.p)
      fboos<-unique(c(fboos,"def"))
      rpart<-rpart(def~.,data=df[,fboos],control=controls.rpart)
      use<-names(rpart$variable.importance)
      print(paste("Ŀǰ������:",length(use)))
      ini.t<-para_C50(df,use,cv.list,ks,controls =controls.C50)
      #print(ini.t[[1]])
      new.1<-ini.t[[2]]["test"]
      print(new.1)
      if(new.1>old.1){
        var.t<-use
        old.1<-new.1
      }
      l<-l-3
      add<-old.1/length(var.t)*0.2
      vars.p[var.t]<-vars.p[var.t]+add
      vars.p<-vars.p/sum(vars.p)
      print(vars.p[1])
    },error=function(e){
      print("ò�Ƴ��˵�����")
    }
    )
  }
  return(var.t)
}

variable_select_rs<-function(df,n){
  old.1<-0.2
  var.t<-c()
  l<-length(df[,1])
  for(i in 1:n){
    tryCatch({
      boos<-sample(1:l,l,replace=T)
      rpart<-rpart(def~.,data=df[boos,],control=controls.rpart)
      use<-names(rpart$variable.importance)
      ini.t<-para_C50(df,use,cv.list,ks,controls=controls.C50)
      #print(ini.t[[1]])
      new.1<-ini.t[[2]]["test"]
      if(new.1>old.1){
        old.1<-new.1
        var.t<-use
      }
    },error=function(e){
      print("ò�Ƴ��˵�����")
    }
    )
  }
  return(var.t)
}

get_var_info<-function(df,vars,targ,way){
  InFo<-c()
  for(i in vars){
    if(i!=targ){
      info<-way(df[,i],df[,targ])
      names(info)<-i
      InFo<-c(InFo,info)
      paste(i,"�Ѿ��õ���Ϣ��")%>%print()
    }
  }
  return(InFo[order(InFo,decreasing = T)])
}

leave_0_point<-function(prob,target){
  prob<-prob%>%as.character()
  
  temp<-table(target,prob)
  te<-names(temp[1,])
  mp<-which(temp[1,]==0|temp[2,]==0)
  last<-length(temp[1,])
  all<-1:last
  nmp<-all[!all%in%mp]
  big<-max(nmp)
  for(i in mp){
    if(i>big){
      cp<-te[i]
      c2p<-te[big]
      prob[prob==cp]<-c2p
    }else{
      cp<-te[i]
      c2p<-te[i+1]
      prob[prob==cp]<-c2p
    }
  }
  return(prob)
}
missing_count<-function(df,target){
  le<-length(df[,1])
  miss<-c()
  for(i in names(df)){
    if(i!=target){
      len<-length(which(is.na(df[,i])))
      m<-len/le
      names(m)<-i
      miss<-c(miss,m)}
  }
  return(miss[order(miss)])
}
miss_handle<-function(df,num.handle=F){
  for(i in names(df)){
    if(is.factor(df[,i])){
      df[,i]<-as.character(df[,i])
      mp<-is.na(df[,i])%>%which()
      df[mp,i]<-"missing"
      df[,i]<-as.factor(df[,i])
    }else{
      if(num.handle){
        temp<-df[,i]
        mp<-is.na(df[,i])%>%which()
        df[mp,i]<--1}
    }
  }
  return(df)
}
trans2miss<-function(df,value){
  for(i in names(df)){
    tp<-which(df[,i]==value)
    df[tp,i]<-NA
  }
  return(df)
}
naive_defi_type<-function(df,dis.list,a){
  for(i in names(df)){
    df[,i]<-as.character(df[,i])%>%as.factor()
    l<-levels(df[,i])%>%length()
    tryCatch({
      if(l>a)df[,i]<-as.character(df[,i])%>%as.numeric()},warning = function(w) {
        print(paste(i,"�ַ��Ͳ���ת����ֵ��"))
      }
    )
  }
  for(i in dis.list){
    df[,i]<-as.character(df[,i])%>%as.factor()
  }
  return(df)
}


count_distinct_value<-function(df,var.list){
  n<-1
  for(i in var.list){
    vec<-df[,i]
    temp<-table(vec)%>%names()
    l<-length(temp)
    va.vec<-c(i,l,temp[1],temp[l])
    if(n==1)va.df<-va.vec else
      va.df<-rbind(va.df,va.vec)
    n<-n+1
  }
  va.df<-data.frame(va.df,row.names = NULL)
  va.df[,2]<-va.df[,2]%>%as.character()%>%as.numeric()
  names(va.df)<-c("����","��Ŀ","��һȡֵ","���ȡֵ")
  va.df<-va.df[order(va.df[,2]),]
  return(va.df)
}
###########################�ֲ���ȡ�����������ֵ����
sepe_var<-function(df,target){
  dis<-c()
  cont<-c()
  for(i in names(df)){
    if(i!=target){
      if(class(df[,i])=="factor")
        dis<-c(dis,i)else cont<-c(cont,i)
    }
  }
  return(list(dis,cont))
}

cv_balance<-function(df,folds,targ){
  g_b<-as.character(df[,targ])
  cv.list<-list()
  remain.g<-which(g_b=="0")
  remain.b<-which(g_b=="1")
  
  g.ns<-length(remain.g)
  g.ns<-g.ns/folds
  b.ns<-length(remain.b)
  b.ns<-b.ns/folds
  for(i in 1:folds){
    samp.g<-sample(remain.g,g.ns,replace = F)
    samp.b<-sample(remain.b,b.ns,replace = F)
    all<-c(samp.b,samp.g)
    cv.list[[i]]<-sample(all,length(all),replace = F)
    remain.g<-remain.g[!remain.g%in%samp.g]
    remain.b<-remain.b[!remain.b%in%samp.b]
  }
  return(cv.list)
}

para_C50<-function(df,var.list,cv.list,ks=ks,controls=controls.C50){
  library(parallel)
  cl <- makeCluster(length(cv.list))
  ignore <- clusterEvalQ(cl, {library(C50); NULL})
  results<-pmult_C50(cl,df[,c(var.list,"def")],cv.list,ks,controls)
  detail<-sapply(results,rbind)
  temp<-apply(detail,1,mean)
  ks.all<-c()
  ks.all["test"]<-temp[1]
  ks.all["train"]<-temp[2]
  stopCluster(cl)
  return(list(detail,ks.all))
}


pmult_C50 <- function(cl,df,cv.list,ks,controls=controls.C50) {
  controls
  df
  ks
  cv.list
  a<-1:length(cv.list)
  mult <- function(s) {
    boost<-C5.0(def~.,data=df[-cv.list[[s]],],trials=100,
                control=controls)
    pred.te<-predict(boost,newdata=df[cv.list[[s]],],type = "prob")
    ks.test<-ks(pred.te[,2],df[cv.list[[s]],"def"],plots = FALSE)
    pred.tr<-predict(boost,newdata=df[-cv.list[[s]],],type = "prob")
    ks.train<-ks(pred.tr[,2],df[-cv.list[[s]],"def"],plots = FALSE)
    c(ks.test,ks.train)
  }
  parLapply(cl, a, mult)
}


library(C50)
controls.C50<-C5.0Control(subset = TRUE, 
                          bands = 0, 
                          winnow =FALSE, 
                          noGlobalPruning = TRUE, 
                          CF = 0.5, 
                          minCases = 10, 
                          fuzzyThreshold = FALSE, 
                          sample = 0.9, 
                          seed = 1948,  
                          earlyStopping = FALSE,
                          label = "outcome")
library(rpart)
controls.rpart<-rpart.control(minsplit =5,
                              cp =0.001,
                              maxcompete =1,
                              maxsurrogate =1,
                              usesurrogate=1,
                              xval =4,
                              surrogatestyle =1,
                              maxdepth = 8)

variable_select_bw<-function(way,df,useful,a,controls){
  old<-0
  use<-c()
  l<-length(useful)
  for(i in l:0){
    tryCatch({
      if(i==0){
        temp<-way(df,useful[use],cv.list,ks,control=controls)
      }else{
        temp<-way(df,useful[c(1:i,use)],cv.list,ks,control=controls)
      }
      new<-temp[[2]]["test"]
      print(paste(i,useful[i]))
      print(new)
      if(old-new>a){
        use<-c(use,i+1)
      }else{
        old<-new
      }},error=function(e){
        use<-c(use,i+1)
        print("ò�Ƴ��˵�����")
      }
    )
  }
  return(list(useful[use],old))
}
get_IV<-function(prob,target){
  prob<-leave_0_point(prob,target)
  mp<-is.na(prob)%>%which()
  prob[mp]<-"missing"
  
  temp<-table(target,prob)
  bad.vec<-temp[2,]
  good.vec<-temp[1,]
  
  bads<-sum(bad.vec)
  goods<-sum(good.vec)
  
  bad.woe<-bad.vec/bads
  good.woe<-good.vec/goods
  woe<-log(bad.woe/good.woe)
  dif<-bad.woe-good.woe
  ivi<-dif*woe
  iv<-sum(ivi)
  return(iv)
}

############################################################������������Լ���
num_test<-function(vec,tar){
  ft<-summary(aov(vec~tar))[[1]][1,5]
  return(ft)
}
############################################################��ɢ��������Լ���
nor_test<-function(vec,tar){
  pv<-chisq.test(vec,tar)$p.value
  return(pv)
}
############################################################�����Լ���
cor_test<-function(df,varlist,cor.rate,iv.list){
  useless<-c()
  for(i in varlist){
    for(j in varlist){
      if(class(df[,i])=="numeric"&class(df[,j])=="numeric"){
        a<-cor.test(df[,i],df[,j])$estimate
        if(a>cor.rate){
          if(iv.list[i]<iv.list[j]){
            print(a)
            print(iv.list[j])
            useless<-c(useless,j)
          }
        }
      }
    }
  }
  return(unique(useless))
}

ks<-function(prob,target,plots=FALSE){
  library(ggplot2)
  library(reshape2)
  temp<-table(target,prob)
  bad.vec<-temp[2,]
  good.vec<-temp[1,]
  
  bads<-sum(bad.vec)
  goods<-sum(good.vec)
  
  bad.cum<-cumsum(bad.vec)
  good.cum<-cumsum(good.vec)
  
  bad.ks<-bad.cum/bads
  good.ks<-good.cum/goods
  
  ks<-good.ks-bad.ks
  id<-names(bad.ks)
  if(plots){
    id<-as.numeric(id)
    df<-data.frame(id,bad.ks,good.ks,ks)
    names(df)[2:3]<-c("���ͻ��ۻ�ռ��","�ÿͻ��ۻ�ռ��")
    df<-melt(df,id.vars="id")
    print(ggplot(df,aes(id,value,colour=variable))+geom_line()+xlab("")+ylab("�ٷֱ�"))
  }
  wh<-which.max(abs(ks))
  big_ks<-ks[wh]
  #print(paste("the biggest ks is:",big_ks))
  #print(paste("the seperation point is:",id[wh]))
  return(big_ks)
}