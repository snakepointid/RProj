require(xgboost)
require(dplyr)
require(Matrix)

p2p<-filter(rawdata,other_var02!=9&other_var02!=7)
p2p<-trans2miss(p2p,-1)
########################################ɾ����ʾ����
#��ɾ������"flag","other","date"ϵ��id,opendid,mail
p2p<-data.frame(p2p,row.names = p2p[,"openid"])
p2p<-select(p2p,-contains("date"))
p2p<-select(p2p,-contains("other"))
p2p<-select(p2p,-contains("flag"))
p2p<-select(p2p,-contains("note"))
p2p<-select(p2p,-contains("brand"))
p2p<-select(p2p,-contains("level"))
p2p<-select(p2p,-contains("score"))
p2p<-select(p2p,-contains("addr"))
p2p<-select(p2p,-c(id,openid,mail,cell,name,auth_stab_mail,auth_mail))
####################################��ȥ����ȫû�еı���
useful<-muti_value(p2p,"def")
p2p<-p2p[,c(useful,"def")]

miss<-missing_count(p2p,"def")
wm<-which(miss<0.95)
useful<-names(miss)[wm]
p2p<-p2p[,c(useful,"def")]
str(p2p)

############################################################��������
temp<-count_distinct_value(p2p,names(p2p))
d.l<-"auth_key_relation"
p2p<-naive_defi_type(p2p,d.l,3)
str(p2p)
####################################���б���ɸѡ
p2p.model<-miss_handle(p2p,num.handle = T)
rpart<-rpart(def~.,data=p2p.model,control=controls.rpart)
useful<-names(rpart$variable.importance)
##############################################�ı����ݽṹ
set.seed(12)
temp<-random_cut(p2p.model[,c(useful,"def")],0.25)
train.p2p<-temp[["train"]]
test.p2p<-temp[["test"]]
train.mat <- sparse.model.matrix(def~., data = train.p2p)
train.l<-train.p2p[,"def"]%>%as.character()%>%as.numeric()
test.mat <- sparse.model.matrix(def~., data = test.p2p)
test.l<-test.p2p[,"def"]%>%as.character()%>%as.numeric()

##############################################�Ż�
evalerror <- function(preds, dtrain) {
  labels <- getinfo(dtrain, "label")
  err <- ks(preds,labels)
  return(list(metric = "ks", value = err))
}
dtrain <- xgb.DMatrix(data =train.mat,label = train.l)
dtest <- xgb.DMatrix(data =test.mat,label = test.l)
watchlist <- list(eval = dtest, train = dtrain)
param <- list(max.depth =3, eta = 0.07, silent = 0,gama=100,
              objective="binary:logistic",subsample=0.7,colsample_bytree=0.5,
              eval_metric=evalerror)
bst <- xgb.train(param, dtrain, nround =1000,watchlist=watchlist,maximize=TRUE)
pred <- predict(bst,test.mat)
ks(pred,test.l,plots = T)

