graph_analysis<-function(df,var.list,target){
library(ggplot2)
for(i in var.list){
  vec<-df[,i]
  default<-df[,target]
  gdf<-data.frame(vec,default)
  if(class(vec)=="factor"){
    print(ggplot(gdf,aes(vec,fill=default))+geom_bar()+xlab(i)+ylab("����"))
    print(ggplot(gdf,aes(vec,fill=default))+geom_bar(position ="fill")+xlab(i)+ylab("�ٷֱ�"))}else
    {
      print(ggplot(gdf,aes(log(vec),fill=default))+geom_histogram()+xlab(i)+ylab("����"))
      print(ggplot(gdf,aes(log(vec),fill=default))+geom_histogram(position ="fill")+xlab(i)+ylab("�ٷֱ�"))
}
}
}


