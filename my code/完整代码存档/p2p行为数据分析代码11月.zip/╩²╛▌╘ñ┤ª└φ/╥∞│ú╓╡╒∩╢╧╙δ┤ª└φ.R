get_outlier<-function(vec,quant=F,change=T){
  if(quant==F){
    m<-mean(vec,na.rm = T)
    s<-sd(vec,na.rm = T)
    max.point<-m+3*s
    min.point<-m-3*s
  }else{
    q3<-quantile(vec,na.rm=T)[4]
    q1<-quantile(vec,na.rm=T)[2]
    max.point<-q3+3*(q3-q1)
    min.point<-q1-3*(q3-q1)
  }
  upper<-which(vec>max.point)
  lower<-which(vec<min.point)
  if(change==T){
    vec[upper]<-max.point
    vec[lower]<-min.point
    return(vec)}else return(c(lower,upper))
}

get_outlier_dis<-function(vec){
  vec<-as.character(vec)
  temp<-table(vec)%>%prop.table()
  outer<-names(temp[temp<0.05])
  outer.p<-vec%in%outer%>%which()
  return(outer.p)
}


outlier_handle<-function(df,var.list){
  for(i in names(df)){
    if(is.numeric(df[,i]))df[,i]<-get_outlier(df[,i],change=TRUE)
  }
  return(df)
}

