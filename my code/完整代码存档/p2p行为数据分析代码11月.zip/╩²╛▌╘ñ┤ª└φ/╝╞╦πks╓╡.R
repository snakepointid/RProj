#һ��ks��
ks<-function(prob,target,plots=FALSE){
  library(ggplot2)
  library(reshape2)
  temp<-table(target,prob)
  bad.vec<-temp[2,]
  good.vec<-temp[1,]
  
  bads<-sum(bad.vec)
  goods<-sum(good.vec)
  
  bad.cum<-cumsum(bad.vec)
  good.cum<-cumsum(good.vec)
  
  bad.ks<-bad.cum/bads
  good.ks<-good.cum/goods
  
  ks<-good.ks-bad.ks
  id<-names(bad.ks)
  if(plots){
  id<-as.numeric(id)
  df<-data.frame(id,bad.ks,good.ks,ks)
  names(df)[2:3]<-c("���ͻ��ۻ�ռ��","�ÿͻ��ۻ�ռ��")
  df<-melt(df,id.vars="id")
  print(ggplot(df,aes(id,value,colour=variable))+geom_line()+xlab("")+ylab("�ٷֱ�"))
  }
  wh<-which.max(abs(ks))
  big_ks<-ks[wh]
  #print(paste("the biggest ks is:",big_ks))
  #print(paste("the seperation point is:",id[wh]))
  return(big_ks)
}
#���ȱʧ������ks
ks_with_con<-function(prob,target){
  mp<-which(is.na(prob))
  prob[mp]<-max(prob)
  ks.max<-ks(prob,target,plots=FALSE)
  prob[mp]<-min(prob)
  ks.min<-ks(prob,target,plots=FALSE)
  ks<-ifelse(abs(ks.max)>abs(ks.min),ks.max,ks.min)
  miss.handle<-ifelse(abs(ks.max)>abs(ks.min),"max","min")
  return(list(ks,miss.handle))
}
#���ȱʧ����ɢks
ks_with_dis<-function(prob,target){
  prob<-as.character(prob)
  mp<-which(is.na(prob))
  prob[mp]<-"missing"
  
  temp<-table(target,prob)
  odds<-temp[2,]/temp[1,]
  temp<-temp[,order(odds)]
  
  bad.vec<-temp[2,]
  good.vec<-temp[1,]
  
  bads<-sum(bad.vec)
  goods<-sum(good.vec)
  
  bad.cum<-cumsum(bad.vec)
  good.cum<-cumsum(good.vec)
  
  bad.ks<-bad.cum/bads
  good.ks<-good.cum/goods
  
  ks<-good.ks-bad.ks
  wh<-which.max(abs(ks))
  big_ks<-ks[wh]
  return(big_ks)
}
#�����ݼ���ks
get_df_ks<-function(df,targ){
  KS<-c()
  MH<-c()
  for(i in names(df)){
    if(i!=targ){
      if(class(df[,i])=="numeric"){
        ks.con<-ks_with_con(df[,i],df[,targ])
        ks<-ks.con[[1]]
        miss.handle<-ks.con[[2]]
        names(miss.handle)<-i
        MH<-c(MH,miss.handle)}else{
          ks<-ks_with_dis(df[,i],df[,targ])
        }
      names(ks)<-i
      KS<-c(KS,ks)
    }
  }
  return(list(KS,MH))
}


