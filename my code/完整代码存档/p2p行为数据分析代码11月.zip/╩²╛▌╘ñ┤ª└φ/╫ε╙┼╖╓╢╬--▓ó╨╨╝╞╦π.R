para_sep_vec<-function(ob.list,sep_wrapper){
  library(parallel)
  cl <- makeCluster(detectCores())
  ndf<-ob.list[[1]]
  ignore <- clusterEvalQ(cl, {library(dplyr); NULL})
  results<-pmult_sep_vec(cl,ob.list,sep_wrapper)
  for(i in results){
    ndf[,i[[2]]]<-i[[1]]
  }
  stopCluster(cl)
  return(ndf)
}

pmult_sep_vec <- function(cl,ob.list,sep_wrapper) {
  df<-ob.list[[1]]
  var.vec<-ob.list[[2]]
  min<-ob.list[[3]]
  sep_wrapper
  a<-1:length(var.vec)
  mult <- function(s) {
    trans.vec<-sep_wrapper(df[,var.vec[s]],df[,"def"],info_way=get_IV,min=min)
    vec.name<-var.vec[s]
    list(trans.vec,vec.name)
  }
  parLapply(cl, a, mult)
}

sep_wrapper<-function(prob,target,info_way=get_IV,min=min){
  leave_0_point<-function(prob,target){
    prob<-prob%>%as.character()
    
    temp<-table(target,prob)
    te<-names(temp[1,])
    mp<-which(temp[1,]==0|temp[2,]==0)
    last<-length(temp[1,])
    all<-1:last
    nmp<-all[!all%in%mp]
    big<-max(nmp)
    for(i in mp){
      if(i>big){
        cp<-te[i]
        c2p<-te[big]
        prob[prob==cp]<-c2p
      }else{
        cp<-te[i]
        c2p<-te[i+1]
        prob[prob==cp]<-c2p
      }
    }
    return(prob)
  }
  
  sep_vec<-function(prob,target,info_way=get_IV,mins=500){
    type<-class(prob)
    if(type=="factor"){
      temp<-dis2con(prob,target)
      prob<-temp[[1]]
      proj.info<-temp[[2]]
    }
    op<-table(prob)%>%names()%>%as.numeric()
    max.iv<-0
    old.points<-c()
    sep.p<-c()
    while(2>1){
      sep<-find_best_point(prob,op,old.points,target,info_way,mins,max.iv=max.iv)
      old.points<-sep[[2]]
      new.iv<-sep[[1]]
      if(max.iv<new.iv){
        max.iv<-new.iv
        sep.p<-old.points
      }else{
        print(paste("Ŀǰ�ֳ�",length(sep.p)+1,"��"))
        break
      }
    }
    if(length(sep.p)==0){
      prob<-prob%>%as.character()
      mp<-which(is.na(prob))
      prob[mp]<-"missing"
      prob[-mp]<-"valued"
      return(prob%>%as.factor())
      break
    }
    print(max.iv)
    if(type=="factor"){
      prob<-dis2dis(prob,proj.info,sep.p)
    }else{
      sep.p<-c(sep.p,-Inf,Inf)
      prob<-cut(prob,sep.p)
    }
    return(prob)
  }
  find_best_point<-function(prob,op,old.points,target,info_way,mins,max.iv){
    op<-op[!op%in%old.points]
    best.p<-c()
    for(i in op){
      new.points<-c(i,old.points,-Inf,Inf)
      temp<-cut(prob,new.points)
      good.count<-table(temp,target)[,1]%>%min()
      bad.count<-table(temp,target)[,2]%>%min()
      all.count<-table(temp)%>%min()
      if(all.count<mins|bad.count<1|good.count<1){
        new.iv<-0}else{
          new.iv<-info_way(temp,target)}
      if(max.iv<new.iv){
        max.iv<-new.iv
        best.p<-i
      }
    }
    old.points<-c(best.p,old.points)
    return(list(max.iv,old.points))
  }
  
  dis2con<-function(prob,target){
    prob<-prob%>%as.character()
    temp<-table(prob,target)
    temp<-temp[order(temp[,2]/temp[,1]),]
    disn<-names(temp[,1])
    proj<-prob
    j<-1
    for(i in disn){
      proj[which(prob==i)]<-j
      j<-j+1
    }
    proj.vec<-1:(j-1)
    names(proj.vec)<-disn
    return(list(proj%>%as.numeric(),proj.vec))
  }
  get_IV<-function(prob,target){
    prob<-leave_0_point(prob,target)
    mp<-is.na(prob)%>%which()
    prob[mp]<-"missing"
    
    temp<-table(target,prob)
    bad.vec<-temp[2,]
    good.vec<-temp[1,]
    
    bads<-sum(bad.vec)
    goods<-sum(good.vec)
    
    bad.woe<-bad.vec/bads
    good.woe<-good.vec/goods
    woe<-log(bad.woe/good.woe)
    dif<-bad.woe-good.woe
    ivi<-dif*woe
    iv<-sum(ivi)
    return(iv)
  }
  
  dis2dis<-function(prob,pi,sep){
    proj<-prob%>%as.character()
    sep<-sep[order(sep)]
    sep<-c(sep,Inf)
    for(i in sep){
      tname<-names(pi[which(pi<=i)])
      name<-c()
      for(n in tname){
        name<-paste(name,n,sep="_")
      }
      proj[which(prob<=i)]<-name
      prob[which(prob<=i)]<-NA
      pi[which(pi<=i)]<-NA
    }
    return(proj%>%as.factor())
  }
  temp<-sep_vec(prob,target,info_way=get_IV,mins=min)
  return(temp)
}