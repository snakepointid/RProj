missing_count<-function(df,target){
  le<-length(df[,1])
  miss<-c()
  for(i in names(df)){
    if(i!=target){
    len<-length(which(is.na(df[,i])))
    m<-len/le
    names(m)<-i
    miss<-c(miss,m)}
  }
  return(miss[order(miss)])
}
miss_valued<-function(df,targ){
  for(i in 1:length(df)){
    target<-df[,targ]%>%as.character()%>%as.numeric()
    temp<-table(target,df[,i])
    if(sum(temp[2,])<sum(target)*0.05){
      df[,i]<-df[,i]%>%as.character()
      mp<-which(is.na(df[,i]))
      df[mp,i]<-"missing"
      df[-mp,i]<-"valued"
      print(names(df)[i])
      names(df)[i]<-paste("mir_",names(df)[i],sep="")
    }
  }
  return(df)
}
miss_handle<-function(df,num.handle=F){
  for(i in names(df)){
    if(is.factor(df[,i])){
    df[,i]<-as.character(df[,i])
    mp<-is.na(df[,i])%>%which()
    df[mp,i]<-"missing"
    df[,i]<-as.factor(df[,i])
    }else{
      if(num.handle){
        temp<-df[,i]
        mp<-is.na(df[,i])%>%which()
        df[mp,i]<--1}
    }
  }
  return(df)
}


trans2miss<-function(df,value){
  for(i in names(df)){
    tp<-which(df[,i]==value)
    df[tp,i]<-NA
  }
  return(df)
}



